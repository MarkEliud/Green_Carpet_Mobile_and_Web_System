<?php
 
  if($_SERVER['REQUEST_METHOD']=='POST'){

	 $connect = mysqli_connect('localhost', 'blupayin_panafrica', 'AweSome2030!','blupayin_greencarpet');
//  $dsn = 'mysql:host=localhost;dbname=blupayin_greencarpet';
// $username = 'blupayin_panafrica';
// $password = 'AweSome2030!';

 $choice = $_POST['choice'];
 $email = $_POST['email'];
 $password = $_POST['psw'];



if( $choice=="Driver")
{

$Sql_Query = "select * from   tbldriver where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
if( $choice=="Customer")
{

$Sql_Query = "select * from tblcustomer where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
 if( $choice=="cleaner")
{

$Sql_Query = "select * from tblcleaner where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
  if( $choice=="supplier")
{

$Sql_Query = "select * from tblsupplier where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
   if( $choice=="Inventory")
{

$Sql_Query = "select * from tblinventory where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
    if( $choice=="Supervisor")
{

$Sql_Query = "select * from tblsupervisor where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
if( $choice=="Finance")
{

$Sql_Query = "select * from tblfinance where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
 if( $choice=="service")
{

$Sql_Query = "select * from tblservice where email = '$email' and password = '$password' and status='Accepted'";
$check = mysqli_fetch_array(mysqli_query($connect,$Sql_Query));
if(isset($check)){
echo "Login";
 }
 else{
 echo "Not approved yet!";
 }
 }
 }else{
 echo "Check Again";
 }


?>