  <footer class="main-footer">
    <strong>Copyright &copy; <?php echo date('Y');?> <a href="#">Green Carpet Cleaning</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
  </footer>