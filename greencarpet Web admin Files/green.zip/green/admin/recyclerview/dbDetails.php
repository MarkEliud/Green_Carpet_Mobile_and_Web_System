<?php 
 define('HOST','localhost');
 define('USER','blupayin_panafrica');
 define('PASS','AweSome2030!');
 define('DB','blupayin_greencarpet');

//  $dsn = 'mysql:host=localhost;dbname=blupayin_greencarpet';
// $username = 'blupayin_panafrica';
// $password = 'AweSome2030!';
