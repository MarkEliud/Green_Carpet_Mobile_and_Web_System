<?php
  include_once('../includes/config.php');
$status = $_POST["status"];


// $isValidEMail = filter_var($email , FILTER_VALIDATE_EMAIL);
if($con){

  if($status=='updateamount'){
    $amount = $_POST["amount"];
$description = $_POST["description"];
    $code = $_POST["code"];
    $sql = "UPDATE orders SET amount='$amount', code='$code' WHERE description LIKE '$description'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
if($status=='quoteamount'){
    $fprice = $_POST["fprice"];
     $desc = $_POST["desc"];
     $sql = "UPDATE orders SET fprice='$fprice' WHERE description LIKE '$desc'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='entermpesa'){
    $fprice = $_POST["fprice"];
     $desc = $_POST["desc"];
     
     $sql = "UPDATE orders SET code='$fprice' WHERE description LIKE '$desc'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='Rejected'){
  //  $code = $_POST["code"];
     $desc = $_POST["desc"];
    $sql = "UPDATE orders SET status='Rejected' WHERE description LIKE '$desc'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='Approved'){
  //  $code = $_POST["code"];
     $desc = $_POST["desc"];
    $sql = "UPDATE orders SET status='Approved' WHERE description LIKE '$desc'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
    if($status=='Allocated'){
  //  $code = $_POST["code"];
     $desc = $_POST["desc"];
    $sql = "UPDATE orders SET cleanerName='Allocated' WHERE description LIKE '$desc'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
    if($status=='Cancelled'){
  //  $code = $_POST["code"];
     $desc = $_POST["desc"];
    $sql = "UPDATE orders SET cleanerName='Cancelled' WHERE description LIKE '$desc'";
  if ($con->query($sql) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
   if($status=='activity'){
    $time = $_POST["time"];
    $activity = $_POST["activity"];
    $name = $_POST["name"];
    $sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
   if($status=='activityUpdate_'){
    $time = $_POST["time"];
    $activity = $_POST["activity"];
    $name = $_POST["name"];

    $sqlq = "UPDATE tblactivity SET activity='$activity' WHERE time LIKE '$time'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
   if($status=='activityUpdate'){
    $time = $_POST["time"];
    $activity = $_POST["activity"];
    $name = $_POST["name"];

    $sqlq = "UPDATE tblactivity SET activity='$activity' WHERE name LIKE '$name'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
    if($status=='CleanerAssign'){
    $code = $_POST["code"];
    $email = $_POST["email"];
     $cleaner = $_POST["fname"];

    $sqlq = "UPDATE orders SET assignee='$email', cleanerName='$cleaner' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
   if($status=='DriverAssign'){
    $code = $_POST["code"];
    $email = $_POST["email"];
  

    $sqlq = "UPDATE orders SET assigneeDriver='$email' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
   if($status=='DriverComplete'){
    $code = $_POST["code"];
    //$email = $_POST["email"];
  

    $sqlq = "UPDATE orders SET dstatus='Completed' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='cleanerUpdate'){
    $code = $_POST["code"];
   // $fprice = $_POST["fprice"];
  //$desc = $_POST["desc"];

    $sqlq = "UPDATE orders SET status='Completed' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='supplyApproved'){
    $code = $_POST["code"];
   // $fprice = $_POST["fprice"];
  //$desc = $_POST["desc"];

    $sqlq = "UPDATE supply SET investatus='Approved' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='supplydel'){
    $code = $_POST["code"];
   // $fprice = $_POST["fprice"];
  //$desc = $_POST["desc"];

    $sqlq = "UPDATE supply SET status='Delivered' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
    if($status=='supplyQuote'){
    //$code = $_POST["code"];
    $amount = $_POST["amount"];
  $desc = $_POST["desc"];

    $sqlq = "UPDATE supply SET amount='$amount' WHERE description LIKE '$desc'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
  if($status=='supplyRejected'){
    $code = $_POST["code"];
   // $fprice = $_POST["fprice"];
  //$desc = $_POST["desc"];

    $sqlq = "UPDATE supply SET investatus='Rejected' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
   if($status=='financeAmount'){
    $code = $_POST["code"];
    $fprice = $_POST["fprice"];
  $desc = $_POST["desc"];
 $id = $_POST["id"];
    $sqlq = "UPDATE supply SET fprice='$fprice',code='$code' WHERE id LIKE '$id'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }

if($status=='selectq'){
    $imageurl = $_POST["imageurl"];
    $qty = $_POST["qty"];
 

    $sqlq = "UPDATE products SET qty='$qty' WHERE image LIKE '$imageurl'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
if($status=='selectitems'){
    $imageurl = $_POST["imageurl"];
    $items = $_POST["items"];
 

    $sqlq = "UPDATE orders SET items='$items' WHERE code LIKE '$imageurl'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
if($status=='selectcleaners'){
    $code = $_POST["code"];
    $cleaners = $_POST["cleaners"];
 

    $sqlq = "UPDATE orders SET assignee='$cleaners' WHERE code LIKE '$code'";

    //$sqlq = "INSERT INTO tblactivity (`name`, `time`, `activity`) VALUES ('$name','$time','$activity')";
  if ($con->query($sqlq) === TRUE) {
  echo "success";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
    if($status=='request'){
    $pname = $_POST["pname"];
    $pack = $_POST["pack"];
     $email = $_POST["email"];
   $desc = $_POST["desc"];
$amount = $_POST["amount"];
    $fprice = $_POST["fprice"];
     $code = $_POST["code"];

    //$sqlq = "UPDATE orders SET status='Complete' WHERE code LIKE '$code'";

    $sqlq = "INSERT INTO supply (`name`, `description`, `pck`,`fprice`,`amount`,`code`,`status`,`email`) VALUES ('$pname','$desc','$pack',
      '$fprice','$amount','$code','Pending','$email')";
  if ($con->query($sqlq) === TRUE) {
  echo "Record updated successfully";
   } else {
  echo "Error updating record: " . $connect->error;
    }
  }
 

}
else{
echo "Connection Error";
}
?>