<div class="headder-top" style="color: pink;">
            <div class="container-fluid">
               <!-- nav -->
               <nav >
                  <div id="logo">
                     <h1><a class="" href="index.php">Baby Day Care Management System</a></h1>
                  </div>
                  <label for="drop" class="toggle">Menu</label>
                  <input type="checkbox" id="drop">
                  <ul class="menu mt-2">
                     <li class="active"><a href="index.php">Home</a></li>
                     <li class="mx-lg-3 mx-md-2 my-md-0 my-1"><a href="about.php">About</a></li>
                     <li><a href="services.php">Services</a></li>
                     <li><a href="enroll.php">Enroll</a></li>
                     <li><a href="baby-sitter.php">Babysitter</a></li>
                     <li><a href="contact.php">Contact Us</a></li>
                     <li><a href="admin/index.php">Admin</a></li>
                  </ul>
               </nav>
               <!-- //nav -->
            </div>
         </div>